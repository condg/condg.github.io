---
title: "Annual End of Year Holiday Party &ndash; December 4th, 2015"
date: 2015-11-18
layout: post
redirect_from:
 - /archive/2015/11/18/Annual-End-of-Year-Holiday-Party-ndash-December-4th-2015.aspx
---


Many of Columbus' technology, creative, and entrepreneurial organizations are getting together this December for a very special holiday celebration.

Please join us on Friday December 4th, 2015, along with members from user groups all over the area as we celebrate a great year in technology at the CoverMyMeds office downtown!

Parking is free, food and drink will be provided along with music, a fun photo booth, presentations and more activities.

**CoverMyMeds**  
[2 Miranova Place 11th floor](https://goo.gl/maps/GbLFL3MPQG82)  
[Columbus, OH 43215](https://goo.gl/maps/GbLFL3MPQG82)

Please register for free on eventbrite if you plan to attend.

[http://columbusmeetupholiday2015.eventbrite.com](http://columbusmeetupholiday2015.eventbrite.com)

