---
title: "Christmas Party for Microsoft User Groups"
date: 2016-12-13
layout: post
redirect_from:
 - /archive/2016/12/13/Christmas-Party-for-Microsoft-User-Groups.aspx
---


Columbus OH has 4 major User Groups focused on Microsoft technologies:

Central Ohio .NET User Group  
The Windows Developer User Group  
Central Ohio Azure User Group  
Buckeye SharePoint User Group

This year, all 4 User Groups come together for an EPIC Christmas Party!

What's in store - Networking | Board Games | Ping Pong | Holiday Spirit. Oh, and great Food & Drinks!

And what's a Holiday Party without some great Prizes? Thanks to Cardinal Solutions, we'll be raffling away an XBox One S and an Amazon Echo!

Ticket sales go to charity. Also highly encouraged are Toys donations to [https://u.osu.edu/osutap/](https://u.osu.edu/osutap/) and Food item donations to [http://www.midohiofoodbank.org/](http://www.midohiofoodbank.org/). Let's spread the love this Holiday Season.

Big cheers for Improving OH for hosting us all. You simply need to be here!

Register Now At:

[https://www.eventbrite.com/e/christmas-party-for-columbus-msft-user-groups-tickets-29997838342?aff=estw](https://www.eventbrite.com/e/christmas-party-for-columbus-msft-user-groups-tickets-29997838342?aff=estw)

