---
title: "Election for 2012 CONDG Officers"
date: 2011-12-06
layout: post
redirect_from:
 - /archive/2011/12/06/Election-for-2012-CONDG-Officers.aspx
---


Elections will be held at the meeting on the 8th. To be eligible to run for office or vote you must have attended three of the last five meetings. The November/December meeting is counted in the five. Attendance is verified by by turning in evaluations. Upon arriving at the meeting you will need to find either James or Bramha. They will verify your name on the eligible voter list and give you a ballot. We will start the meeting with a few words from the candidates, followed by casting of votes. Votes will be tabulated during the talk and the panel of officers for 2012 will be announced at the end of the meeting.

The following candidates are running for the indicated office:

President – Brian Sherwin, Chris Farrell

Vice President – Bramha Ghosh

Treasurer – Brandon Schott

Secretary – Vince Fabro, Alex Moore.

If you have any questions, please e-mail [contact@condg.org](mailto:contact@condg.org)

