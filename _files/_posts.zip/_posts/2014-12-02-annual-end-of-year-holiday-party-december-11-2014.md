---
title: "Annual End of Year Holiday Party &ndash; December 11, 2014"
date: 2014-12-02
layout: post
redirect_from:
 - /archive/2014/12/02/Annual-End-of-Year-Holiday-Party-ndash-December-11-2014.aspx
---


Everyone is invited to attend the annual CONDG End of Year Holiday Party this December 11<sup>th</sup>, 2014 beginning at 6:00 PM.

There will be food, networking, fun, and more!

**Toy / Food Drive**

Once again we will be hosting our toy / food drive. All toys will be donated to Toys-for-Tots and food to the Mid Ohio Food Bank.

**Meeting Location**

In order to accommodate a larger group and provide extra space for other activities we will once again be using the facilities provided by one of our Annual Sponsors.

Improving Enterprises      
[One Easton Oval        
Suite 175         
Columbus, OH 43219](http://goo.gl/maps/GmnKI)

**Board Elections**

As part of the annual meeting we will be holding elections for next year’s officers. Officer rolls include: President, Vice-President, Treasurer, and Secretary. For more information about each role please read the Bylaws posted on the condg.org website. If you wish to run for a position please email [contact@condg.org](mailto:contact@condg.org) with the position you wish to run for.

Any individual that has attended four meetings in 2014 is eligible to vote in the elections.

We look forward to seeing you!

