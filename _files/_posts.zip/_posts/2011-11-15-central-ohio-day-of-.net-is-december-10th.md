---
title: "Central Ohio Day of .NET is December 10th"
date: 2011-11-15
layout: post
redirect_from:
 - /archive/2011/11/15/Central-Ohio-Day-of-.NET-is-December-10th.aspx
---

The Central Ohio Day of .NET will be held at Indiana Wesleyan University at 3455 Mill Run Drive, Suite 200 in Hilliard.

This is a one-day conference that will enable attendees to see talks on a wide range of subjects from some of the most popular speakers in the .NET community.

For more information, included a list of talks please visit [www.cododn.org](http://www.cododn.org) (please note that more talks will be going up on the agenda this week!)

To register go to [http://cododn.eventbrite.com/](http://cododn.eventbrite.com/)

This is always a great event and we look forward to seeing a strong turnout for the Columbus .NET community!
