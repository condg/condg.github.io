---
title: "Results of CONDG elections"
date: 2011-12-08
layout: post
redirect_from:
 - /archive/2011/12/08/Results-of-CONDG-elections.aspx
---

Your officers for 2012:

- President – Brian Sherwin
- Vice President – Bramha Ghosh
- Secretary – Vince Fabro
- Treasurer – Brandon Schott


Congratulations to the new officers!
