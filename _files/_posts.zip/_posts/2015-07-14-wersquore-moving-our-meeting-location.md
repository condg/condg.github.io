---
title: "We&rsquo;re Moving Our Meeting Location"
date: 2015-07-14
layout: post
redirect_from:
 - /archive/2015/07/14/Wersquore-Moving-Our-Meeting-Location.aspx
---

We have always been very thankful for being allowed to meet each month at the Microsoft Office, but unfortunately for the next few months we will have to move our meeting location while renovations are being done in the Microsoft Office.

We would like to thank our sponsor [ICC](http://icctechnology.com/) for graciously offering to provide us a space to host the meetings for the new few months.

Their office is located on the north side of town by I270 and Cleveland Ave.

[![image](http://condg.org/images/condg_org/WindowsLiveWriter/WereMovingOurMeetingLocation_7E41/image_3.png "image")](https://goo.gl/maps/zamLx)

[Information Control Company       
2500 Corporate Exchange Drive        
Columbus, OH 43231](https://goo.gl/maps/zamLx)

Please join us for the July 23rd, August 27th, September 24th and October 22nd meetings at the new location!
